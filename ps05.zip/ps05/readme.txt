(i) & (ii) Codebase and Instruction to run code:

This is Jupyter Notebook file and run the code in jupyter notebook.

1. It is required to run all the notebook cell in order
2. First need to run the Imports and then run all the code cell sequentially.
3. All the cells of the notebook are properly commented for better understanding
4. The dataset should be inside a directory named 'datasets' and datasets folder should be inside the project folder.Or if it is in different folder used the path of that folder.
5. For google colab user, upload the notebook in colab, use the dataset link (commented out in the original notebook) and run all the cell sequentially.
df = pd.read_csv('https://query.data.world/s/uiqo2olpduwvxagb5vuv5oevfryysy?dws=00000')
6. Internet connection is required to download the datasets.

(iii) Names and Versions of all the packages/libraries

Python 3.9.7
Pandas 1.3.4	
NumPy 1.20.3
Matplotlib 3.4.3
Seaborn 0.11.2
Timeit 3.9.7
sklearn 0.24.2
imblearn 0.7.0
warnings 3.9.7

(iv) Data set

We have used an existing data set. Data dictionary is available in the folder as a separate excel file. the data set is available in the below link:
https://data.world/kishoresjv/telecomchurn/workspace/file?filename=telecom_churn_data.csv
